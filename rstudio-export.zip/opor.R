# Instale rvest package
#install.packages("ggplot2")

# Carrega biblioteca
library(rvest)
library(dplyr)
library(ggplot2)


# Define a URL da página de lançamentos populares no Steam
url <- "https://store.steampowered.com/search/?sort_by=Released_DESC&category1=998"

# Lê a página e cria um objeto de nó de página
page <- read_html(url)

# Extrai nomes dos jogos usando o seletor CSS
game_names <- html_nodes(page, ".title") %>% html_text()

# Exibe os nomes dos jogos
game_names


# Cria um data frame com os nomes dos jogos
game_data <- data.frame(game_name = game_names)

# Agrupa os dados por nome de jogo e conta quantas vezes cada jogo aparece
game_counts <- game_data %>% group_by(game_name) %>% tally()

# Cria o gráfico de barras





# Adiciona uma coluna de preço ao data frame game_counts com os preços extraídos
game_counts$price <- game_prices

# Cria o gráfico usando a coluna de preço como a variável y
game_counts %>% 
  na.omit() %>%
ggplot( aes(y = reorder(game_name, price), x = price)) +
  geom_bar(stat = "identity", fill = "#008080") +
  geom_text(aes(label = round(price)), vjust = -0.5, size = 3.5) +
  xlab("Jogos") + ylab("Preço") +
  ggtitle("Lançamentos populares de jogos no Steam") +
  theme_classic() + 
  theme(axis.text.y = element_text(angle = 0, hjust = 1, size = rel(1)),
        axis.text.x = element_text(size = rel(0.5)),
        panel.grid.major = element_line(color = "gray")) +
  labs(subtitle = "Novos lançamentos populares no Steam")

